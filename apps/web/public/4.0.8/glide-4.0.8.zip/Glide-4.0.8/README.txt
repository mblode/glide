Glide 4.0.8 production release. Variable fonts include wght and opsz axes.
