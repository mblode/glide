Glide 4.0.0 production release. Variable fonts include wght and opsz axes.
