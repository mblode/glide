Glide 4.0.15 production release. Variable fonts include wght and opsz axes.
