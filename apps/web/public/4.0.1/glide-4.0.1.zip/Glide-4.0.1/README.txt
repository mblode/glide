Glide 4.0.1 production release. Variable fonts include wght and opsz axes.
