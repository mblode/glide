Glide 4.0.10 production release. Variable fonts include wght and opsz axes.
