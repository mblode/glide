Glide 4.0.11 production release. Variable fonts include wght and opsz axes.
