Glide 4.0.12 production release. Variable fonts include wght and opsz axes.
