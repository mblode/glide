Glide 4.0.7 production release. Variable fonts include wght and opsz axes.
