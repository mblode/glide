Glide 4.0.13 production release. Variable fonts include wght and opsz axes.
