Glide 4.0.2 production release. Variable fonts include wght and opsz axes.
