Glide 4.0.6 production release. Variable fonts include wght and opsz axes.
