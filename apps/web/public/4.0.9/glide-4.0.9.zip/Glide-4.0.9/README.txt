Glide 4.0.9 production release. Variable fonts include wght and opsz axes.
