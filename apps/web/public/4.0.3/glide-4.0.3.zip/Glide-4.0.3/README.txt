Glide 4.0.3 production release. Variable fonts include wght and opsz axes.
