Glide 4.0.4 production release. Variable fonts include wght and opsz axes.
