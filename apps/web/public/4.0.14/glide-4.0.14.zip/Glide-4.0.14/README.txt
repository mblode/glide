Glide 4.0.14 production release. Variable fonts include wght and opsz axes.
