Glide 4.0.5 production release. Variable fonts include wght and opsz axes.
